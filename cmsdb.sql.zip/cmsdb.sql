-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 24, 2021 at 11:40 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17684475_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcementid` int(11) NOT NULL,
  `teacherid` int(11) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` varchar(10000) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcementid`, `teacherid`, `title`, `description`, `datetime`) VALUES
(6, 2, 'Test Announcement', 'Server maintenance.<br />\r\n<br />\r\nDate: 1/10/2021<br />\r\nTime: 9:00 AM', '08:05 pm 30/09/2021');

-- --------------------------------------------------------

--
-- Table structure for table `attendences`
--

CREATE TABLE `attendences` (
  `attendenceid` int(11) NOT NULL,
  `childrenid` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendences`
--

INSERT INTO `attendences` (`attendenceid`, `childrenid`, `status`, `date`, `time`) VALUES
(10, 4, 'absent', '27/09/2021', '11:35:04 PM'),
(13, NULL, NULL, '01/01/1970', '11:23:54 PM'),
(15, 13, 'present', '16/12/2021', '01:56:56 PM'),
(17, 5, 'present', '16/12/2021', '10:59:26 AM'),
(18, 5, 'present', '08/09/2021', '11:00:26 AM'),
(19, 4, 'absent', '16/12/2021', '11:00:40 AM');

-- --------------------------------------------------------

--
-- Table structure for table `childrens`
--

CREATE TABLE `childrens` (
  `childrenid` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  `fullname` varchar(150) DEFAULT NULL,
  `icnumber` varchar(20) DEFAULT NULL,
  `age` varchar(20) DEFAULT NULL,
  `allergic` varchar(500) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `childrens`
--

INSERT INTO `childrens` (`childrenid`, `parentid`, `fullname`, `icnumber`, `age`, `allergic`, `photo`, `datetime`) VALUES
(4, 3, 'iskandar roslan bin kamaludin', '090909099891', '10', 'Heart rate increase when with jagung', '8.jpg', '23:30:20 2021-09-29'),
(5, 3, 'kamariah adreena binti kamaludin', '070819097864', '8', 'None', 'alena-aenami-lost-1k.jpg', '23:31:26 2021-09-29'),
(13, 11, 'nur ain syathirah', '980226115756', '6', 'milk', 'photoViewer.jpeg', '13:53:57 2021-12-15'),
(14, 14, 'Siti Zamira Binti Ahmad', '190816065326', '3', 'None', 'download1.jpg', '14:08:10 2021-12-15');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymentid` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  `childid` int(11) DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `month` varchar(15) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `date` varchar(25) DEFAULT NULL,
  `time` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentid`, `parentid`, `childid`, `fee`, `month`, `status`, `date`, `time`) VALUES
(3, 3, 4, 700, 'Sep', 'paid', '29/09/2021', '10:10 PM'),
(4, 3, 5, 500, 'Aug', 'paid', '01/09/2021', '10:17 PM'),
(5, 11, 13, 350, 'Dec', 'paid', '16/12/2021', '01:57 PM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `icnumber` varchar(20) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `fullname`, `icnumber`, `address`, `phone`, `photo`, `role`, `datetime`) VALUES
(2, 'sarah', 'c05771e61ad36d14eeb66cb6d00c2ebc', 'sarahliana binti megat nasrun', '981104066751', 'no 29 jalan angerik taman desa permai, 81920 kota bahru, melaka', '0149827831', NULL, '1', NULL),
(3, 'aminah', '90b74c589f46e8f3a484082d659308bd', 'siti aminah binti wahab', '891129065674', '9', '0137776521', NULL, '0', '23:28:40 2021-09-29'),
(4, 'admin', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL, '2', NULL),
(6, 'khairunisa', '473742eb88bbb2cea04986a157306929', 'Khairunisa binti ibrahim', '950927066564', 'b-1-a jalan pangsapuri emas, taman gombok, 41410 gombak, selangor', '0137675841', 'alena-aenami-4.jpg', '1', '21:06:31 2021-09-30'),
(11, 'Ainsyathirah', '62467b65bbb0e10247c7a32f1db9a38b', 'nur ain syathirah muhamad nazri', '980226115756', '1257 JALAN MAWAR 10, TAMAN PERMINT JAYA CHENDERING,', '0189124262', NULL, '0', '13:50:32 2021-12-15'),
(13, 'cintot', '81dc9bdb52d04dc20036dbd8313ed055', 'Nurul Intan Balqish', '991017105328', 'No 32A, Jalan 6/3 Pandan Perdana', '01127263228', NULL, '0', '13:50:43 2021-12-15'),
(14, 'ahmad', '61243c7b9a4022cb3f8dc3106767ed12', 'AHMAD BIN HASSAN', '9812345689', 'NOM 25, Jalan Anggerik 21, Jalan Setia Alam', '0139888685', NULL, '0', '14:06:46 2021-12-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcementid`),
  ADD KEY `teacherid` (`teacherid`);

--
-- Indexes for table `attendences`
--
ALTER TABLE `attendences`
  ADD PRIMARY KEY (`attendenceid`),
  ADD KEY `childrenid` (`childrenid`);

--
-- Indexes for table `childrens`
--
ALTER TABLE `childrens`
  ADD PRIMARY KEY (`childrenid`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`paymentid`),
  ADD KEY `childid` (`childid`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcementid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendences`
--
ALTER TABLE `attendences`
  MODIFY `attendenceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `childrens`
--
ALTER TABLE `childrens`
  MODIFY `childrenid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `paymentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`teacherid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendences`
--
ALTER TABLE `attendences`
  ADD CONSTRAINT `attendences_ibfk_1` FOREIGN KEY (`childrenid`) REFERENCES `childrens` (`childrenid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `childrens`
--
ALTER TABLE `childrens`
  ADD CONSTRAINT `childrens_ibfk_1` FOREIGN KEY (`parentid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`childid`) REFERENCES `childrens` (`childrenid`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`parentid`) REFERENCES `users` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
