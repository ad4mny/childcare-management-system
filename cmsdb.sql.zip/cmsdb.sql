-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 30, 2021 at 10:17 PM
-- Server version: 8.0.26
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcementid` int NOT NULL,
  `teacherid` int NOT NULL,
  `title` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(10000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `datetime` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcementid`, `teacherid`, `title`, `description`, `datetime`) VALUES
(1, 1, 'back to school celebration with children', 'Make the happening session this summer with invited clown and gathering bunch of brainy together!\r\n<br>\r\n<br>\r\nTime: 10:00 AM - 6:00 PM<br>\r\nDate: 27/10/2021<br>\r\nLocation: Bonda Sediah', '04:51 am 30/09/2021'),
(2, 1, 'Aiman birthday celebration sponsered by his parents and the ministry of finance! Come join us!', 'Coming soon, TBA.', '04:51 am 30/09/2021'),
(6, 2, 'Test Announcement', 'Server maintenance.<br />\r\n<br />\r\nDate: 1/10/2021<br />\r\nTime: 9:00 AM', '08:05 pm 30/09/2021');

-- --------------------------------------------------------

--
-- Table structure for table `attendences`
--

CREATE TABLE `attendences` (
  `attendenceid` int NOT NULL,
  `childrenid` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `time` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendences`
--

INSERT INTO `attendences` (`attendenceid`, `childrenid`, `status`, `date`, `time`) VALUES
(1, 2, 'present', '21/09/2021', '11:35:04 PM'),
(2, 1, 'absent', '21/09/2021', '11:35:04 PM'),
(3, 2, 'absent', '22/09/2021', '11:35:04 PM'),
(4, 1, 'absent', '22/09/2021', '11:35:04 PM'),
(5, 2, 'present', '23/09/2021', '11:35:04 PM'),
(6, 1, 'absent', '23/09/2021', '11:35:04 PM'),
(8, 2, 'absent', '27/09/2021', '11:35:04 PM'),
(9, 4, 'present', '23/09/2021', '11:35:04 PM'),
(10, 4, 'absent', '27/09/2021', '11:35:04 PM');

-- --------------------------------------------------------

--
-- Table structure for table `childrens`
--

CREATE TABLE `childrens` (
  `childrenid` int NOT NULL,
  `parentid` int NOT NULL,
  `fullname` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `icnumber` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `age` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `allergic` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `datetime` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `childrens`
--

INSERT INTO `childrens` (`childrenid`, `parentid`, `fullname`, `icnumber`, `age`, `allergic`, `photo`, `datetime`) VALUES
(1, 1, 'ivy sarah binti adam aiman', '260707144554', '2', NULL, NULL, NULL),
(2, 1, 'arya hawa binti adam aiman', '260707144556', '2', NULL, NULL, NULL),
(4, 3, 'iskandar roslan bin kamaludin', '090909099891', '10', 'Heart rate increase when with jagung', '8.jpg', '23:30:20 2021-09-29'),
(5, 3, 'kamariah adreena binti kamaludin', '070819097864', '8', 'None', 'alena-aenami-lost-1k.jpg', '23:31:26 2021-09-29');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymentid` int NOT NULL,
  `parentid` int NOT NULL,
  `childid` int DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `month` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `time` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentid`, `parentid`, `childid`, `fee`, `month`, `status`, `date`, `time`) VALUES
(1, 1, 2, 700, 'September', NULL, '30/09/2021', '09:21 PM'),
(3, 3, 4, 700, 'Sep', 'paid', '29/09/2021', '10:10 PM'),
(4, 3, 5, 500, 'Aug', 'paid', '01/09/2021', '10:17 PM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int NOT NULL,
  `username` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fullname` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `icnumber` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `datetime` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `fullname`, `icnumber`, `address`, `phone`, `photo`, `role`, `datetime`) VALUES
(1, 'adaman', 'c05771e61ad36d14eeb66cb6d00c2ebc', 'adam aiman bin zulkornain', '981104066751', 'no 26 jalan perjiranan 11/18 bandar dato onn 81100 johor bahru johor                        ', '0108884287', '81.jpg', '0', '02:01:36 2021-09-28'),
(2, 'sarah', 'c05771e61ad36d14eeb66cb6d00c2ebc', 'sarahliana binti megat nasrun', '981104066751', 'no 29 jalan angerik taman desa permai, 81920 kota bahru, melaka', '0149827831', NULL, '1', NULL),
(3, 'aminah', '90b74c589f46e8f3a484082d659308bd', 'siti aminah binti wahab', '891129065674', '9', '0137776521', NULL, '0', '23:28:40 2021-09-29'),
(4, 'admin', 'c05771e61ad36d14eeb66cb6d00c2ebc', NULL, NULL, NULL, NULL, NULL, '2', NULL),
(6, 'khairunisa', '473742eb88bbb2cea04986a157306929', 'Khairunisa binti ibrahim', '950927066564', 'b-1-a jalan pangsapuri emas, taman gombok, 41410 gombak, selangor', '0137675841', 'alena-aenami-4.jpg', '1', '21:06:31 2021-09-30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcementid`),
  ADD KEY `teacherid` (`teacherid`);

--
-- Indexes for table `attendences`
--
ALTER TABLE `attendences`
  ADD PRIMARY KEY (`attendenceid`),
  ADD KEY `childrenid` (`childrenid`);

--
-- Indexes for table `childrens`
--
ALTER TABLE `childrens`
  ADD PRIMARY KEY (`childrenid`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`paymentid`),
  ADD KEY `childid` (`childid`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcementid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendences`
--
ALTER TABLE `attendences`
  MODIFY `attendenceid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `childrens`
--
ALTER TABLE `childrens`
  MODIFY `childrenid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `paymentid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`teacherid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendences`
--
ALTER TABLE `attendences`
  ADD CONSTRAINT `attendences_ibfk_1` FOREIGN KEY (`childrenid`) REFERENCES `childrens` (`childrenid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `childrens`
--
ALTER TABLE `childrens`
  ADD CONSTRAINT `childrens_ibfk_1` FOREIGN KEY (`parentid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`childid`) REFERENCES `childrens` (`childrenid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`parentid`) REFERENCES `users` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
